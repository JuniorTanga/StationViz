#pragma once
#include <QObject>
#include <QString>
#include <QVector>
#include <memory>
#include "sclNodes/substation.h"
#include "sclNodes/ied.h"

namespace stationviz::scl {

class SclParser : public QObject {
    Q_OBJECT
public:
    explicit SclParser(QObject* parent=nullptr);

    bool loadFile(const QString& path);

    const QVector<Substation>& substations() const { return substations_; }
    const QVector<Ied>& ieds() const { return ieds_; }

signals:
    void parsed();
    void error(QString message);

private:
    QVector<Substation> substations_;
    QVector<Ied> ieds_;

    void parseIEDs(class pugi::xml_node scl);
    void parseSubstation(class pugi::xml_node scl);
};

} // namespace stationviz::scl
