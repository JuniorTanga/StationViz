#pragma once
#include <QObject>
#include <QVariant>
#include <memory>
#include "SclParser.hpp"

namespace stationviz::scl {

class SclManager : public QObject {
    Q_OBJECT
public:
    explicit SclManager(QObject* parent=nullptr);

    Q_INVOKABLE bool load(const QString& sclPath);

    Q_INVOKABLE QStringList listIEDs() const;
    Q_INVOKABLE QStringList listVoltageLevels() const;

    const QVector<Substation>& substations() const { return parser_.substations(); }
    const QVector<Ied>& ieds() const { return parser_.ieds(); }

signals:
    void modelChanged();
    void error(QString msg);

private:
    SclParser parser_;
};

} // namespace stationviz::scl
