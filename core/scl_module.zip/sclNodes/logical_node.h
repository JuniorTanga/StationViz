#pragma once
#include <QString>
#include "lnref.h"

namespace stationviz::scl {

class LogicalNode {
public:
    LnRef ref;
    QString desc;
};

} // namespace stationviz::scl
