#pragma once
#include <QString>
#include <QVector>
#include "scl_common.h"
#include "conducting_equipment.h"
#include "connectivity_node.h"
#include "logical_node.h"

namespace stationviz::scl {

class Bay {
public:
    QString name, desc;
    SclId   key;

    QVector<ConductingEquipment> equipments;
    QVector<ConnectivityNode>    connectivityNodes;
    QVector<LogicalNode>         lNodes;
};

} // namespace stationviz::scl
