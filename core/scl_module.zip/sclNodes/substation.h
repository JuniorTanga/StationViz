#pragma once
#include <QString>
#include <QVector>
#include "scl_common.h"
#include "voltage_level.h"
#include "power_transformer.h"

namespace stationviz::scl {

class Substation {
public:
    QString name, desc;
    SclId   key;

    QVector<VoltageLevel>     voltageLevels;
    QVector<PowerTransformer> transformers;
};

} // namespace stationviz::scl
