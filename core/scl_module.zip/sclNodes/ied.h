#pragma once
#include <QString>
#include <QVector>
#include "lnref.h"

namespace stationviz::scl {

class Ied {
public:
    QString name;
    QString manufacturer;
    QString desc;
    QVector<LnRef> lnList;
};

} // namespace stationviz::scl
