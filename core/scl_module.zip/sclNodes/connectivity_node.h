#pragma once
#include <QString>
#include "scl_common.h"

namespace stationviz::scl {

class ConnectivityNode {
public:
    QString name;
    QString path;
    SclId   key;
};

} // namespace stationviz::scl
