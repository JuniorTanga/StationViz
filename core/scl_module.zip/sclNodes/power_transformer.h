#pragma once
#include <QString>
#include <QVector>
#include "scl_common.h"

namespace stationviz::scl {

struct TransformerWinding {
    QString name;
    Quantity ratedU;
    Quantity ratedS;
};

class PowerTransformer {
public:
    QString name, desc;
    SclId   key;

    QVector<TransformerWinding> windings;
};

} // namespace stationviz::scl
