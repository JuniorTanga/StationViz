#pragma once
#include <QString>

namespace stationviz::scl {

struct LnRef {
    QString iedName, ldInst, lnClass, lnInst, prefix;
    QString lnPath;
};

} // namespace stationviz::scl
