#pragma once
#include <QString>
#include <QVector>
#include "scl_common.h"
#include "bay.h"

namespace stationviz::scl {

class VoltageLevel {
public:
    QString name, desc;
    SclId   key;

    Quantity voltage;
    Quantity nominalVoltage;
    int nomFreq = 0;
    int numPhases = 0;

    QVector<Bay> bays;
};

} // namespace stationviz::scl
