#pragma once
#include <QString>
#include <QVector>
#include "scl_common.h"
#include "lnref.h"

namespace stationviz::scl {

class ConductingEquipment {
public:
    QString name, desc;
    CeType  type = CeType::Unknown;
    SclId   key;

    QVector<QString> terminals;
    QVector<LnRef>   lnRefs;
};

} // namespace stationviz::scl
